from cProfile import label
from math import lgamma
from re import I
from tkinter import *
import tkinter
from PIL import ImageTk, Image
import webbrowser

root = Tk()
root.geometry('2880x1800')

title = root.title("Duke Game Recap")
root.configure(background = "black")

# each of the following are methods created in order to be called by the buttons created further down

def UNCArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369869")
def PittArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369997")
def CuseArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401370015")
def VirginiaArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401370052")
def FSUArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369868")
def WakeArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369867")
def BCArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369922")
def ClemsonArt2():
    webbrowser.open_new("https://www.cbssports.com/college-basketball/gametracker/recap/NCAAB_20220210_DUKE@CLEM/")
def VirginiaArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369866")
def UNCArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369957")
def NDArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401265089")
def LouisvilleArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401370117")
def ClemsonArt1():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369865")
def CuseArt1():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369864")
def FSUArt1():
    webbrowser.open_new("https://www.cbssports.com/college-basketball/gametracker/recap/NCAAB_20220118_DUKE@FSU/")
def NCStateArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369863")
def WakeArt1():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401370066")
def MiamiArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369862")
def GeorgiaTechArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/recap/_/gameId/401369861")
def DickieVLink():
    webbrowser.open_new("https://www.espn.com/espn/dickvitale/story/_/id/33413181/read-dick-vitale-letter-retiring-duke-college-basketball-legend-coach-k")
def vidlink():
    webbrowser.open_new("https://www.youtube.com/watch?v=UTZISX_M77I")
def gotwitter():
    webbrowser.open_new("https://twitter.com/DukeMBB")
def goinstagram():
    webbrowser.open_new("https://www.instagram.com/dukembb/?hl=en")
def gofacebook():
    webbrowser.open_new("https://www.facebook.com/DukeMBB/")

#second game against North Carolina

UNCRecap2 = Button(root, text = "North Carolina Recap, 3/5/2022", fg = "blue", command = UNCArt2)
UNCRecap2.grid(row = 0, column = 1)
UNCGame2 = ImageTk.PhotoImage(Image.open("UNC2.jpeg"))
UNCGameButton2 = Button(image = UNCGame2, command = UNCArt2)
UNCGameButton2.grid(row = 1, column = 1)

#Pittsburgh Game

pittRecap = Button(root, text = "Pitt Recap, 3/1/22", fg = "blue", command = PittArt)
pittRecap.grid(row = 0, column = 2)
pittGame = ImageTk.PhotoImage(Image.open("PittGame.jpeg"))
pittGameButton = Button(image = pittGame, command = PittArt)
pittGameButton.grid(row = 1, column = 2)

#second game against Syracuse

cuseRecap2 = Button(root, text = "Syracuse Recap, 2/26/22", fg = "blue", command = CuseArt2)
cuseRecap2.grid(row = 0, column = 3)
syracuseGame = ImageTk.PhotoImage(Image.open("SyracuseGame.jpeg"))
syracuseGameButton = Button(image = syracuseGame, command = CuseArt2)
syracuseGameButton.grid(row = 1, column = 3)

#second game against Virginia

virginiaRecap2 = Button(root, text = "Virginia Recap, 2/23/22", fg = "blue", command = VirginiaArt2)
virginiaRecap2.grid(row = 0, column = 4)
virginiaGame2 = ImageTk.PhotoImage(Image.open("VirginiaGame.jpeg"))
virginiaGameButton2 = Button(image = virginiaGame2, command = VirginiaArt2)
virginiaGameButton2.grid(row = 1, column = 4)

#second game against Florida State

FSURecap2 = Button(root, text = "Florida State Recap, 2/19/22", fg = "blue", command = FSUArt2)
FSURecap2.grid(row = 0, column = 5)
fsuGame2 = ImageTk.PhotoImage(Image.open("FSUGame.jpeg"))
fsuGameButton2 = Button(image = fsuGame2, command = FSUArt2)
fsuGameButton2.grid(row = 1, column = 5)

#second game against Wake Forest

wakeRecap2 = Button(root, text = "Wake Forest Recap, 2/15/22", fg = "blue", command = WakeArt2)
wakeRecap2.grid(row = 2, column = 1)
wakeGame2 = ImageTk.PhotoImage(Image.open("WakeGame.jpeg"))
wakeGameButton2 = Button(image = wakeGame2, command = WakeArt2)
wakeGameButton2.grid(row = 3, column = 1)

#Boston College Game

BCRecap = Button(root, text = "Boston College Recap, 2/12/2022", fg = "blue", command = BCArt)
BCRecap.grid(row = 2, column = 2)
BCGame = ImageTk.PhotoImage(Image.open("BCGame.jpeg"))
BCGameButton = Button(image = BCGame, command = BCArt)
BCGameButton.grid(row = 3, column = 2)

#second game against Clemson

ClemsonRecap2 = Button(root, text = "Clemson Recap, 2/10/22", fg = "blue", command = ClemsonArt2)
ClemsonRecap2.grid(row = 2, column = 3)
ClemsonGame2 = ImageTk.PhotoImage(Image.open("ClemsonGame.jpeg"))
ClemsonGameButton2 = Button(image = ClemsonGame2, command = ClemsonArt2)
ClemsonGameButton2.grid(row = 3, column = 3)

#first game against Virginia

virginiaRecap1 = Button(root, text = "Virginia Recap, 2/7/22", fg = "blue", command = VirginiaArt)
virginiaRecap1.grid(row = 2, column = 4)
VirginiaGame1 = ImageTk.PhotoImage(Image.open("VirginiaGame1.jpeg"))
VirginiaGame1Button = Button(image = VirginiaGame1, command = VirginiaArt)
VirginiaGame1Button.grid(row = 3, column = 4)

#first game against North Carolina

UncRecap = Button(root, text = "North Carolina Recap, 2/5/22", fg = "blue", command = UNCArt)
UncRecap.grid(row = 2, column = 5)
UNCGame = ImageTk.PhotoImage(Image.open("UNCGame1.jpeg"))
UNCGameButton = Button(image = UNCGame, command = UNCArt)
UNCGameButton.grid(row = 3, column = 5)

#Notre Dame Game

NDRecap = Button(root, text = "Notre Dame Recap, 1/31/22", fg = "blue", command = NDArt)
NDRecap.grid(row = 4, column = 1)
ndGame = ImageTk.PhotoImage(Image.open("NDGame.jpeg"))
ndGameButton = Button(image = ndGame, command = NDArt)
ndGameButton.grid(row = 5, column = 1)

#Louisville Game

LouisvilleRecap = Button(root, text = "Louisville Recap, 1/29/22", fg = "blue", command = LouisvilleArt)
LouisvilleRecap.grid(row = 4, column = 2)
LGame = ImageTk.PhotoImage(Image.open("dukevslouisville.jpeg"))
LGameButton = Button(image = LGame, command = LouisvilleArt)
LGameButton.grid(row = 5, column = 2)

#first game against Clemson

ClemsonRecap1 = Button(root, text = "Clemson Recap, 1/25/22", fg = "blue", command = ClemsonArt1)
ClemsonRecap1.grid(row = 4, column = 3)
ClemsonGame1 = ImageTk.PhotoImage(Image.open("clemsonATduke.jpeg"))
ClemsonGame1Button = Button(image = ClemsonGame1, command = ClemsonArt1)
ClemsonGame1Button.grid(row = 5, column = 3)

#first game against Syracuse

cuseRecap1 = Button(root, text = "Syracuse Recap, 1/22/22", fg = "blue", command = CuseArt1)
cuseRecap1.grid(row = 4, column = 4)
cuseGame1 = ImageTk.PhotoImage(Image.open("DukeSyracuse.jpeg"))
cuseGame1Button = Button(image = cuseGame1, command = CuseArt1)
cuseGame1Button.grid(row = 5, column = 4)

#first game agianst Florida State

FSURecap1 = Button(root, text = "Florida State Recap, 1/18/22", fg = "blue", command = FSUArt1)
FSURecap1.grid(row = 4, column = 5)
fsuGame1 = ImageTk.PhotoImage(Image.open("DukeatFSU.jpeg"))
fsuGame1Button = Button(image = fsuGame1, command = FSUArt1)
fsuGame1Button.grid(row = 5, column = 5)

#NC State Game

NCStateRecap = Button(root, text = "NC State Recap, 1/15/22", fg = "blue", command = NCStateArt)
NCStateRecap.grid(row = 6, column = 1)
ncstateGame = ImageTk.PhotoImage(Image.open("DukeNCState.jpeg"))
ncstateGameButton = Button(image = ncstateGame, command = NCStateArt)
ncstateGameButton.grid(row = 7, column = 1)

#First Game against Wake Forest

WakeRecap1 = Button(root, text = "Wake Forest Recap, 1/12/22", fg = "blue", command = WakeArt1)
WakeRecap1.grid(row = 6, column = 2)
WakeGame1 = ImageTk.PhotoImage(Image.open("WakeGame1.jpeg"))
WakeGame1Button = Button(image = WakeGame1, command = WakeArt1)
WakeGame1Button.grid(row = 7, column = 2)

#Miami Game

MiamiRecap = Button(root, text = "Miami Recap, 1/8/22", fg = "blue", command = MiamiArt)
MiamiRecap.grid(row = 6, column = 3)
MiamiGame = ImageTk.PhotoImage(Image.open("MiamiGame.jpeg"))
MiamiGameButton = Button(image = MiamiGame, command = MiamiArt)
MiamiGameButton.grid(row = 7, column = 3)

#Georgia Tech Game

GTechRecap = Button(root, text = "Georgia Tech Recap, 1/4/22", fg = "blue", command = GeorgiaTechArt)
GTechRecap.grid(row = 6, column = 4)
GTechGame = ImageTk.PhotoImage(Image.open("GtechGame.jpeg"))
GTechGameButton = Button(image = GTechGame, command = GeorgiaTechArt)
GTechGameButton.grid(row = 7, column = 4)

#Begin Page 2

def pagetwo():
    global newbanners

    two = Toplevel()
    two.title('Coach K Tribute')
    two.geometry('2880x1800')

    #next three are aptly named after the social media the button will take the user to

    twitterButton = Button(two, text = "Go to Duke Mens Basketball Twitter", fg = "blue", command = gotwitter)
    twitterButton.grid(row = 20, column = 6)

    facebookButton = Button(two, text = "Go to Duke Mens Basketball Facebook", fg = "blue", command = gofacebook)
    facebookButton.grid(row = 21, column = 6)

    instagramButton = Button(two, text = "Go to Duke Mens Basketball Instagram", fg = "blue", command = goinstagram)
    instagramButton.grid(row = 22, column = 6)

    banners = Image.open("Banners.jpeg")
    resized = banners.resize((1080, 360), Image.ANTIALIAS)
    newbanners = ImageTk.PhotoImage(resized)
    
    bannerslabel = Label(two, image = newbanners)
    bannerslabel.grid(row = 0, column = 2, columnspan = 4, rowspan = 4)
    
    DickieVLetter = Button(two, text = "Read Dickie V's letter to Coach K", fg = "blue", command = DickieVLink)
    DickieVLetter.grid(row = 1, column = 1)

    Watch = Button(two, text = "Watch Coach K address Duke fans", fg = "blue", command = vidlink)
    Watch.grid(row = 1, column = 6)

    #each of the following is an image added to the screen with each made global, otherwise the program would not recognize it

    global newcouple
    couple = Image.open("CoachandMickie.jpeg")
    resizedcouple = couple.resize((480,480), Image.ANTIALIAS)
    newcouple = ImageTk.PhotoImage(resizedcouple)

    coupleLabel = Label(two, image = newcouple)
    coupleLabel.grid(row = 8, column = 0, columnspan = 6, rowspan = 25)

    global newbrotherhood
    brotherhood = Image.open("Banner.jpeg")
    resizebro = brotherhood.resize((300,100), Image.ANTIALIAS)
    newbrotherhood = ImageTk.PhotoImage(resizebro)

    brotherhoodLabel = Label(two, image = newbrotherhood)
    brotherhoodLabel.grid(row = 6, column = 0, columnspan = 6)

    global Dukevid
    Dukevid = ImageTk.PhotoImage(Image.open("Kvid.jpeg"))
    DukevidButton = Button(two, image = Dukevid)
    DukevidButton.grid(row = 0, column = 6)

    global DickPic
    DickPic = ImageTk.PhotoImage(Image.open("DickieV.jpeg"))
    DickLabel = Label(two, image = DickPic)
    DickLabel.grid(row = 0, column = 1)

#end page 2


openpg2 = Button(root, text = "Go to Tribute Page", command = pagetwo, fg = "blue")
quit_button = Button(root, text = "Quit", command = root.quit, fg = "blue")









quit_button.grid(row = 10,column = 20,sticky = "se")
openpg2.grid(row = 11, column = 20)






root.mainloop()
        

        
