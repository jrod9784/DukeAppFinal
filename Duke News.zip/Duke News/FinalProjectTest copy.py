from cProfile import label
from math import lgamma
from re import I
from tkinter import *
from PIL import ImageTk, Image
import webbrowser

root = Tk()
root.geometry('2880x1800')

title = root.title("Duke News")
root.configure(background = "black")

def PittArt():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/game/_/gameId/401369997")
def CuseArt2():
    webbrowser.open_new("https://www.espn.com/mens-college-basketball/game/_/gameId/401370015")

pittRecap = Button(root, text = "Pitt Recap, 3/1/22", fg = "blue", command = PittArt)
pittRecap.grid(row = 0, column =1)
pittGame = ImageTk.PhotoImage(Image.open("PittGame.jpeg"))
pittGameButton = Button(image = pittGame, command = PittArt)
pittGameButton.grid(row = 1, column = 1)

cuseRecap2 = Button(root, text = "Syracuse Recap, 2/26/22", fg = "blue", command = CuseArt2)
cuseRecap2.grid(row = 0, column = 2)
syracuseGame = ImageTk.PhotoImage(Image.open("SyracuseGame.jpeg"))
syracuseGameButton = Button(image = syracuseGame, command = CuseArt2)
syracuseGameButton.grid(row = 1, column = 2)

virginiaRecap2 = Button(root, text = "Virginia Recap, 2/23/22", fg = "blue")
virginiaRecap2.grid(row = 0, column = 3)
virginiaGame2 = ImageTk.PhotoImage(Image.open("VirginiaGame.jpeg"))
virginiaGameButton2 = Button(image = virginiaGame2)
virginiaGameButton2.grid(row = 1, column = 3)

FSURecap2 = Button(root, text = "Florida State Recap, 2/19/22", fg = "blue")
FSURecap2.grid(row = 0, column = 4)
fsuGame2 = ImageTk.PhotoImage(Image.open("FSUGame.jpeg"))
fsuGameButton2 = Button(image = fsuGame2)
fsuGameButton2.grid(row = 1, column = 4)

wakeRecap2 = Button(root, text = "Wake Forest Recap, 2/15/22", fg = "blue")
wakeRecap2.grid(row = 0, column = 5)
wakeGame2 = ImageTk.PhotoImage(Image.open("WakeGame.jpeg"))
wakeGameButton2 = Button(image = wakeGame2)
wakeGameButton2.grid(row = 1, column = 5)

BCRecap = Button(root, text = "Boston College Recap, 2/12/2022", fg = "blue")
BCRecap.grid(row = 2, column = 1)
BCGame = ImageTk.PhotoImage(Image.open("BCGame.jpeg"))
BCGameButton = Button(image = BCGame)
BCGameButton.grid(row = 3, column = 1)

ClemsonRecap2 = Button(root, text = "Clemson Recap, 2/10/22", fg = "blue")
ClemsonRecap2.grid(row = 2, column = 2)
ClemsonGame2 = ImageTk.PhotoImage(Image.open("ClemsonGame.jpeg"))
ClemsonGameButton2 = Button(image = ClemsonGame2)
ClemsonGameButton2.grid(row = 3, column = 2)

virginiaRecap1 = Button(root, text = "Virginia Recap, 2/7/22", fg = "blue")
virginiaRecap1.grid(row = 2, column = 3)
VirginiaGame1 = ImageTk.PhotoImage(Image.open("VirginiaGame1.jpeg"))
VirginiaGame1Button = Button(image = VirginiaGame1)
VirginiaGame1Button.grid(row = 3, column = 3)

UncRecap = Button(root, text = "North Carolina Recap, 2/5/22", fg = "blue")
UncRecap.grid(row = 2, column = 4)
UNCGame = ImageTk.PhotoImage(Image.open("UNCGame1.jpeg"))
UNCGameButton = Button(image = UNCGame)
UNCGameButton.grid(row = 3, column = 4)

NDRecap = Button(root, text = "Notre Dame Recap, 1/31/22", fg = "blue")
NDRecap.grid(row = 2, column = 5)
ndGame = ImageTk.PhotoImage(Image.open("NDGame.jpeg"))
ndGameButton = Button(image = ndGame)
ndGameButton.grid(row = 3, column = 5)

LouisvilleRecap = Button(root, text = "Louisville Recap, 1/29/22", fg = "blue")
LouisvilleRecap.grid(row = 4, column = 1)
LGame = ImageTk.PhotoImage(Image.open("dukevslouisville.jpeg"))
LGameButton = Button(image = LGame)
LGameButton.grid(row = 5, column = 1)

ClemsonRecap1 = Button(root, text = "Clemson Recap, 1/25/22", fg = "blue")
ClemsonRecap1.grid(row = 4, column = 2)
ClemsonGame1 = ImageTk.PhotoImage(Image.open("clemsonATduke.jpeg"))
ClemsonGame1Button = Button(image = ClemsonGame1)
ClemsonGame1Button.grid(row = 5, column = 2)

cuseRecap1 = Button(root, text = "Syracuse Recap, 1/22/22", fg = "blue")
cuseRecap1.grid(row = 4, column = 3)
cuseGame1 = ImageTk.PhotoImage(Image.open("DukeSyracuse.jpeg"))
cuseGame1Button = Button(image = cuseGame1)
cuseGame1Button.grid(row = 5, column = 3)

FSURecap1 = Button(root, text = "Florida State Recap, 1/18/22", fg = "blue")
FSURecap1.grid(row = 4, column = 4)
fsuGame1 = ImageTk.PhotoImage(Image.open("DukeatFSU.jpeg"))
fsuGame1Button = Button(image = fsuGame1)
fsuGame1Button.grid(row = 5, column = 4)

NCStateRecap = Button(root, text = "NC State Recap, 1/15/22", fg = "blue")
NCStateRecap.grid(row = 4, column = 5)
ncstateGame = ImageTk.PhotoImage(Image.open("DukeNCState.jpeg"))
ncstateGameButton = Button(image = ncstateGame)
ncstateGameButton.grid(row = 5, column = 5)

WakeRecap1 = Button(root, text = "Wake Forest Recap, 1/12/22", fg = "blue")
WakeRecap1.grid(row = 6, column = 1)
WakeGame1 = ImageTk.PhotoImage(Image.open("WakeGame1.jpeg"))
WakeGame1Button = Button(image = WakeGame1)
WakeGame1Button.grid(row = 7, column = 1)

MiamiRecap = Button(root, text = "Miami Recap, 1/8/22", fg = "blue")
MiamiRecap.grid(row = 6, column = 2)
MiamiGame = ImageTk.PhotoImage(Image.open("MiamiGame.jpeg"))
MiamiGameButton = Button(image = MiamiGame)
MiamiGameButton.grid(row = 7, column = 2)

GTechRecap = Button(root, text = "Georgia Tech Recap, 1/4/22", fg = "blue")
GTechRecap.grid(row = 6, column = 3)
GTechGame = ImageTk.PhotoImage(Image.open("GtechGame.jpeg"))
GTechGameButton = Button(image = GTechGame)
GTechGameButton.grid(row = 7, column = 3)

def pagetwo():
    two = Toplevel()
    two.title('2021 Game Recap')

openpg2 = Button(root, text = "2021 Games", command = pagetwo, fg = "blue")
quit_button = Button(root, text = "Quit", command = root.quit, fg = "blue")








quit_button.grid(row = 1,column = 20,sticky = "se")
openpg2.grid(row = 2, column = 20)






root.mainloop()
        

        
